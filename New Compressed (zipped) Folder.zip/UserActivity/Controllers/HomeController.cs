﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UserActivity.Controllers
{
    public class HomeController : Controller
    {
        UserDbEntities obj = new UserDbEntities();
        public ActionResult Index()
        {
            var listofData = obj.UserTables.ToList();
            return View(listofData);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(UserTable model)
        {
            obj.UserTables.Add(model);
            obj.SaveChanges();
            ViewBag.Message = "Data Insert Successfully";
            return View();
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var Data = obj.UserTables.Where(x => x.UserId == id).FirstOrDefault();
            return View(Data);
        }
        [HttpPost]
        public ActionResult Edit(UserTable Model)
        {
            var Data = obj.UserTables.Where(x =>x.UserId == Model.UserId).FirstOrDefault();
            if(Data != null)
            {
                Data.UserName = Model.UserName;
                Data.Password = Model.Password;
                Data.ConfirmPassword = Model.ConfirmPassword;
                Data.DisplayName = Model.DisplayName;
                Data.Gender = Model.Gender;
                Data.EmailId = Model.EmailId;
                Data.ContactNumber = Model.ContactNumber;
                Data.CollageName = Model.CollageName;
                Data.City = Model.City;
                Data.State = Model.State;
                obj.SaveChanges();
            }
            return RedirectToAction("Index");
        }
        public ActionResult Detail(int id)
        {
            var data = obj.UserTables.Where(x => x.UserId == id).FirstOrDefault();
            return View(data);
        }
        public ActionResult Delete (int id)
        {
            var data = obj.UserTables.Where(x => x.UserId == id).FirstOrDefault();
            obj.UserTables.Remove(data);
            obj.SaveChanges();
            ViewBag.Message = "Record Delete Successfully";
            return RedirectToAction("Index");
        }
    }
}