﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UserActivity.Controllers
{
    public class HeadController : Controller
    {
       
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserTable objUser)
        {
            if(ModelState.IsValid)
            {
                using (UserDbEntities db = new UserDbEntities())
                {
                    var op = db.UserTables.Where(a => a.UserName.Equals(objUser.UserName) && a.Password.Equals(objUser.Password)).FirstOrDefault();
                    if(op !=null)
                    {
                        Session["UserId"] = op.UserId.ToString();
                        Session["UserName"] = op.UserName.ToString();
                        Session["DisplayName"] = op.DisplayName.ToString();
                        Session["Gender"] = op.Gender.ToString();
                        Session["EmailId"] = op.EmailId.ToString();
                        Session["ContactNumber"] = op.ContactNumber.ToString();
                        Session["CollageName"] = op.CollageName.ToString();
                        Session["City"] = op.City.ToString();
                        Session["State"] = op.State.ToString();
                        return RedirectToAction("UserDashBoard");
                    }
                }
            }
            return View(objUser);
        }
        public ActionResult UserDashboard()
        {
            if(Session["UserId"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        public ActionResult Class1()
        {
            return View();
        }
       
        public ActionResult Study()
        {
            return View();
        }
        public ActionResult quiz()
        {
            return View();
        }
    }
}